# Databricks notebook source
df = spark.read.option("header","True").option("InferSchechema","True").parquet("/Volumes/bankingprojectcatalog/default/bronze/*.parquet")

display(df)

# COMMAND ----------

df.select("Geography").distinct().display()

# COMMAND ----------

from pyspark.sql.functions import *

df = df.withColumn("CountryCode", 
                       when(col("Geography")=="Spain","ES")
                       .when(col("Geography")=="France","FR")
                       .when(col("Geography")=="Germany","DE"))

display(df)

              

# COMMAND ----------

df = df.withColumn("CreditStatus",
                   when((col("CreditScore")>0) & (col("CreditScore")<=300),"Low")
                   .when((col("CreditScore")>300) & (col("CreditScore")<=600),"Medium")
                   .when((col("CreditScore")>600) & (col("CreditScore")<=900),"High")
                   .when((col("CreditSCore")>900),"Very High"))

display(df)

# COMMAND ----------

df = df.withColumn("UniqueId",
                   concat(
                       substring(col("Surname"),0,3)
                       ,substring(col("CustomerId"),-3,3)                            
))

display(df)

# COMMAND ----------

df.write.mode("overwrite").parquet("/Volumes/bankingprojectcatalog/default/silver")

# COMMAND ----------

