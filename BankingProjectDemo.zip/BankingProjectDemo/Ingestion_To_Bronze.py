# Databricks notebook source
schema = spark.read.option("header", "True").option("Inferschema","True").csv("/Volumes/bankingprojectcatalog/default/rawinput").schema


df = (spark.readStream
      .schema(schema)
      .option("header", "True")
      .option("maxFilesPerTrigger", 1)
      .csv("/Volumes/bankingprojectcatalog/default/rawinput")
      .writeStream
      .format("parquet")
      .option("checkpointLocation", "/Volumes/bankingprojectcatalog/default/bronze/_checkpoint")
      .trigger(once=True)
      .start("/Volumes/bankingprojectcatalog/default/bronze")

)

df.awaitTermination()

# COMMAND ----------

