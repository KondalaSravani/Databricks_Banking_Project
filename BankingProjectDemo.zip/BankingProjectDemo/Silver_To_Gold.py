# Databricks notebook source
from pyspark.sql.functions import *

df = spark.read.option("header","True").option("InferSchema","True").parquet("/Volumes/bankingprojectcatalog/default/silver/*.parquet")

display(df)

# COMMAND ----------

dim1 = df.select(["RowNumber","Geography","CountryCode"])
display(dim1)

# COMMAND ----------

dim2 = df.select(["CustomerId","Surname","Gender","Age"])
display(dim2)

# COMMAND ----------

dim3 = df.select(["UniqueId","Tenure","HasCrCard","IsActiveMember","Exited"])
display(dim3)

# COMMAND ----------

fact = df.select(["RowNumber","CustomerId","UniqueId","CreditScore","Balance","NumOfProducts","EstimatedSalary","CreditStatus"]) 
display(fact)

# COMMAND ----------

gold = fact.join(dim1,on="RowNumber",how="inner").join(dim2,on="CustomerId",how="inner").join(dim3,on="UniqueId",how = "inner")
display(gold)


# COMMAND ----------

gold.write.mode("overwrite").parquet("/Volumes/bankingprojectcatalog/default/gold")

# COMMAND ----------

gold.write.mode("overwrite").saveAsTable("gold")
display(spark.sql("select * from gold"))

# COMMAND ----------

